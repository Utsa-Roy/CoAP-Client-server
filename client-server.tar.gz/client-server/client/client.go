/*Mentor: Utsa Roy
Developer: Riom Sen
Version: 0.02
©IIEST, Shibpur*/

package main

import (
	"log"
	"os"
	"bytes"
	"time"
	"github.com/dustin/go-coap"
	"example.com/cryptofunc"
)

var client_id []byte
var iot_id []byte
var resource_id[]byte
var key [32]byte
var message_id int

func handleError(message string , err error) {
	if err != nil {
		log.Fatalf(message,err)
		os.Exit(1)
	}
}

func interact(c *coap.Conn, req coap.Message) {
	/*This is a demo function 
	It demonstrates how we can interact with the server after authentication*/
	message, err := cryptofunc.Encrypt(key,[]byte("PING"))
	handleError("Encryption error: %s ",err)
	req.Payload = message
	req.SetPathString("/execute")
	for {
		time.Sleep(1 * time.Second) 
		//this statement is purely optional, should be deleted as soon as possible
		rv, err := c.Send(req)//send enquiry, receive response
		handleError("Error sending request: %v", err)
		msg, err := cryptofunc.Decrypt(key,rv.Payload)
		log.Printf("The message received is %s \n",msg) 

	}
}
func main() {

	serverpublic, err := cryptofunc.ExtractPublicKey("Server.publickey")
	handleError("Unable to extract public key: %s ",err)
	clientprivate, err := cryptofunc.ExtractPrivateKey("Client.privatekey")
	handleError("Unable to extract private key: %s ",err)

	client_id = []byte("Sudipt")
	iot_id = []byte("aa1234")
	resource_id = []byte("tempre")
	message_id =1
	encry_message , raw_sym_key, err := cryptofunc.PackSOR(client_id,iot_id,resource_id,serverpublic,clientprivate)
	copy(key[:], raw_sym_key)
	handleError("Unable to pack Request: %s",err)

	//prepare your datagram
	req := coap.Message{
		Type:      coap.Confirmable,
		Code:      coap.GET,
	}
	req.MessageID = 1
	req.Payload = encry_message

	/*path := "/some/path"
	if len(os.Args) > 1 {
		path = os.Args[1]
	}*/

	req.SetOption(coap.ETag, "weetag")
	req.SetOption(coap.MaxAge, 3)
	req.SetPathString("/authenticate")

	c, err := coap.Dial("udp", "localhost:5683")
	handleError("Error dialing: %v",err)

	rv, err := c.Send(req)//send enquiry, receive response
	handleError("Error sending request: %v", err)
	
	if rv != nil {
		//response, err := cryptofunc.Decrypt(key,rv.Payload) //decrypt payload
		if bytes.Equal(rv.Payload, []byte("FAILURE")) {
			log.Printf("Authentication failed\n")
		}
		response , err := cryptofunc.Decrypt(key,rv.Payload)
		handleError("Decryption failed", err)
		if bytes.Equal(response,[]byte("SUCCESS")) {
			log.Printf("Authentication succeded\n")
			interact(c,req)
		}
	}else {
		log.Printf("Hello, empty response\n")
	}

}
