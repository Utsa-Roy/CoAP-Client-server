In order to use this library, keep cryptofunc.go (and this file) in a suitable folder, and execute "go mod init example.com/cryptofunc" in it.
Again while importing in any suitable program, type import "example.com/cryptofunc".
Then in the console, execute "go mod edit -replace example.com/cryptofunc=[path of cryptofunc.go]"
Finally execute "go mod tidy"
Before running any of the modules for the first time
Install in your GOPATH: go get -u "gitlab.com/elktree/ecc"
Install in your GOPATH: go get -u golang.org/x/crypto/...
