package cryptofunc

/*Mentor: Utsa Roy
Developer: Riom Sen
Version: 0.02
©IIEST, Shibpur*/

import (
	"os"
	"errors"
	//"fmt"
        "crypto/elliptic"
        "crypto/rand"
	"gitlab.com/elktree/ecc"
	"golang.org/x/crypto/chacha20poly1305"
)

// Before running any of the modules for the first time
//Install in your GOPATH: go get -u gitlab.com/elktree/ecc
//Install in your GOPATH: go get -u golang.org/x/crypto/...


func GenerateKey(id string) error {
	//The given function generates a pair of public and private key.
	//It stores them in the file id.privatekey and id.publickey respectively
	//It stores them in that folder where the method is called
	//It uses the elliptic curve P256 (a.k.a. secp256r1)


	public, private, err := ecc.GenerateKeys(elliptic.P256()) //generates the key
        if err != nil {
                return err
        }

	fname1 := id + ".privatekey"
	f1, err := os.OpenFile(fname1, os.O_WRONLY|os.O_CREATE, 0755)
        if err != nil {
                return err
        }

	content_private, err := private.Marshal() //According to ASN.1 Der format
	if err != nil {
		return err
	}
	_, err = f1.Write(content_private) //writing privatekey
        if err != nil {
                return err
        }
	f1.Close()

	fname2 := id + ".publickey"
	f2, err := os.OpenFile(fname2,os.O_WRONLY|os.O_CREATE,0755)
        if err != nil {
                return err
        }

	content_public := public.Marshal() // According to section 4.36 of ANSI X9.62

	_,err=f2.Write(content_public) //writing publickey
        if err != nil {
                return err
       	}

	f2.Close()

	return nil
}

func ExtractPrivateKey(fname string) (*ecc.PrivateKey,error) {
	content_privatekey := make([]uint8,121)//initialising the variable to store the private key
	
	var privatekey *ecc.PrivateKey
	
	f1, err := os.OpenFile(fname,os.O_RDONLY,0755)
	if err != nil {
		return privatekey,err
	}
	
	_,err = f1.Read(content_privatekey)
	if err != nil {
		return privatekey,err
	}
	
	f1.Close()
	privatekey, err = ecc.UnmarshalPrivateKey(content_privatekey)

	return privatekey,err
}

func ExtractPublicKey(fname string) (*ecc.PublicKey, error) {

	content_publickey := make([]uint8,65)
	var publickey *ecc.PublicKey // initialising the variable where we shall store the public key

	f1, err := os.OpenFile(fname,os.O_RDONLY,0755)
	if err != nil {
		return publickey, err
	}
	_,err = f1.Read(content_publickey)//reading abscissa and ordinate as a byte array
	if err != nil{
		return publickey, err
	}
	publickey  = ecc.UnmarshalPublicKey(elliptic.P256(),content_publickey)
	f1.Close()
	return publickey, err
}

func PackSOR(client_id []byte, iot_id []byte, resource_id []byte, server *ecc.PublicKey, client *ecc.PrivateKey) ([]byte,[]byte, error){
	/*This function takes client_id, iot_id and resource_id,
	creates a 32-bit secure key for symmetric key cryptography,
	and encrypts them in a message, with a digital signature attached.
	It is typically expected that client will use it and send message*/
	
	var encrypted_message []byte
	var message []byte
	sym_key := make([]byte,32)
	_ , err := rand.Read(sym_key)
	if err != nil {
		return encrypted_message,sym_key, err
	}
	message = append(message, client_id[:]...)
	message = append(message, iot_id[:]...)
	message = append(message, resource_id[:]...)
	message = append(message, sym_key[:]...)
	signature , err := client.SignMessage(message)
	if err != nil {
		return encrypted_message, sym_key,err
	}
	message = append(message, signature...)
	encrypted_message , err = server.Encrypt(message)
	return encrypted_message , sym_key, err
}

func UnpackSOR(message []byte, client *ecc.PublicKey, server *ecc.PrivateKey) ([]byte, []byte, []byte, []byte, error) {
	client_id := make([]byte,6)
	iot_id := make([]byte,6)
	resource_id := make([]byte,6)
	sym_key := make([]byte,32)

	message , err := server.Decrypt(message)
	if err != nil {
		return client_id, iot_id, resource_id, sym_key, err
	}
	verified, err := client.VerifyMessage(message[:50],message[50:]) //6+6+6+32=50=>The size of message
	if err != nil {
		return client_id, iot_id, resource_id, sym_key, err
	}
	if !verified {
		return client_id, iot_id, resource_id , sym_key, errors.New("Verification failed")
	}
	copy(client_id,message[:6])
	copy(iot_id,message[6:12])
	copy(resource_id,message[12:18])
	copy(sym_key,message[18:50])

	return client_id, iot_id, resource_id, sym_key , nil
}

func Encrypt(key [32]byte, msg []byte) ([]byte , error) {
	var encryptedMsg []byte
	//NewX returns a XChaCha20-Poly1305 AEAD that uses the given 256-bit key.
	//It takes a 24-bit nonce which is cryptographically more secure
	aead, err := chacha20poly1305.NewX(key[:])
	if err != nil {
		return encryptedMsg, err
	}
	// Select a random nonce, and leave capacity for the ciphertext.
	nonce := make([]byte, aead.NonceSize(), aead.NonceSize()+len(msg)+aead.Overhead())
	_, err = rand.Read(nonce)
	if err != nil {
		return encryptedMsg, err
	}
	// Encrypt the message and append the ciphertext to the nonce.
	encryptedMsg = aead.Seal(nonce, nonce, msg, nil)
	return encryptedMsg, nil
}

func Decrypt(key [32]byte, msg []byte) ([]byte, error) {
	var decryptedMsg []byte
	aead, err := chacha20poly1305.NewX(key[:])
	if err != nil {
		return decryptedMsg, err
	}
	if len(msg) < aead.NonceSize() {
		return decryptedMsg, errors.New("Ciphertext is too short")
	}
	// Split nonce and ciphertext.
	nonce, ciphertext := msg[:aead.NonceSize()], msg[aead.NonceSize():]

	// Decrypt the message and check it wasn't tampered with.
	decryptedMsg, err = aead.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		panic(err)
	}
	return decryptedMsg, nil
}
